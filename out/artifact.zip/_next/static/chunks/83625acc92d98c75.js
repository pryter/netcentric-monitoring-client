__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/871ab61f5e45de2e.js",
  "static/chunks/turbopack-380e24004c867c1c.js"
])
